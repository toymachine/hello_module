define(function() {

    var LOGLEVEL_DEBUG = 0;
    var LOGLEVEL_ERROR = 1;

    function getLogger(name, level) {
	var effective_level = level || LOGLEVEL_DEBUG;

	function prepareMsg(args, call_level)
	{
            if(effective_level > call_level) {
		return false;
            }
            var pad = function(n, c) {
		c = c || 2;
		var t = 10;
		var s = "";
		for (var i = 1; i < c; i++) {
                    if (n < t) {
			s += "0";
                    }
                    t *= 10;
		}
		return s + n;
            };

            var d = new Date(Date.now());
            var s = pad(d.getHours()) + ":" +
                pad(d.getMinutes()) + ":" +
                pad(d.getSeconds()) + ":" +
                pad(d.getMilliseconds(), 3);

            var _msg = [s, name];

            for(var i = 0; i < args.length; i++) {
		_msg.push(args[i]);
            }

            return _msg;
	}

	return {
            isDebug: function() {
		return true;
            },
            debug: function(msg) {

		var _msg = prepareMsg(arguments, LOGLEVEL_DEBUG);
		if(_msg !== false) {
                    if (window.Testing && Testing.log) {
			Testing.log("debug: " + _msg.join(", "));
                    } else if (window.debug && debug.log) {
			debug.log(_msg.join(", "));
                    } else if (window.console) {
			var c = console; // to prevent removal by build system
			c.log(_msg);
                    }
		}
            },

            error: function(msg) {
		var _msg = prepareMsg(arguments, LOGLEVEL_ERROR);
		if (window.Testing && Testing.log) {
                    Testing.log("ERROR: " + _msg);
		} else if (window.debug && debug.log) {
                    debug.log(_msg);
		} else if (window.console) {
                    var c = console; // to prevent removal by build system
                    if (c.error) {
			c.error(_msg);
                    } else {
			c.log(_msg);
                    }
		}
            },

            exception: function(msg, e) {

		msg += ": " + (e === undefined ? "Unknown exception caught" :
                               (e.message ? e.message : e.error_message) + (e.error_code ? (" (" + e.error_code + ")") : ""));

		if (window.Testing && Testing.log) {
                    Testing.log("EXCEPTION: " + msg);
		} else if (window.debug && debug.log) {
                    debug.log(msg);
		} else if (window.console && window.console.error) {
                    console.error(msg);
                    if (window.console.trace) {
			console.trace();
                    }
		}
            }
	};
    };

    logging = getLogger('root');
    logging.LOGLEVEL_DEBUG = LOGLEVEL_DEBUG;
    logging.LOGLEVEL_ERROR = LOGLEVEL_ERROR;

    return logging;
});




